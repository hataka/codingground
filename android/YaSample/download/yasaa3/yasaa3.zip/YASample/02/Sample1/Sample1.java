package ya.sample;

import android.os.*;
import android.app.*;

public class Sample1 extends Activity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sample1);
    }
}
