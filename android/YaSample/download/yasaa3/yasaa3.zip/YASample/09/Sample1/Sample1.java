package ya.sample;

import android.appwidget.*;

public class Sample1 extends AppWidgetProvider
{
}
