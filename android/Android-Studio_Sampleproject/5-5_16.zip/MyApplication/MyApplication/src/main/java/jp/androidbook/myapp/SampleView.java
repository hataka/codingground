package jp.androidbook.myapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

public class SampleView extends View {

	public SampleView(Context context){
		super(context);
	}

	public SampleView(Context context, AttributeSet attrs){
		super(context,attrs);
	}

	public SampleView(Context context, AttributeSet attrs, int defstyle){
		super(context,attrs, defstyle);
	}

	/* list 5-5
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		Paint p = new Paint();
		p.setColor(Color.BLUE);
		c.drawRect(new RectF(50, 50, 150, 150), p);
		p.setColor(Color.RED);
		c.drawOval(new RectF(100, 100, 200, 200), p);
	} */

	/* list 5-6
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		Paint p = new Paint();
		p.setColor(Color.RED);
		p.setStyle(Paint.Style.STROKE);
		RectF r = new RectF();
		for(int i = 1;i <= 10;i++){
			r.set(i * 22.5f, i * 22.5f, 100 + i * 22.5f, 100 + i * 22.5f);
			c.drawRect(r, p);
		}
	} */

	/* list 5-7
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		Paint p = new Paint();
		p.setColor(Color.RED);
		p.setStyle(Paint.Style.STROKE);
		RectF r = new RectF();
		for(int i = 1;i <= 10;i++){
			p.setStrokeWidth(i); // ☆
			r.set(i * 22.5f, i * 22.5f, 100 + i * 22.5f, 100 + i * 22.5f);
			c.drawRect(r, p);
		}
	} */

	/* list 5-8
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		Paint p = new Paint();
		p.setColor(Color.RED);
		p.setStyle(Paint.Style.STROKE);
		p.setStrokeWidth(50f);
		float[] data = new float[]{50,50,150,150,150,150,250,50};
		Paint.Cap[] caps = new Paint.Cap[]{Paint.Cap.SQUARE,
			Paint.Cap.ROUND, Paint.Cap.BUTT};
		for(int i = 0;i < 3;i++){
			p.setStrokeCap(caps[i]);
			c.drawLines(data, p);
			for(int j = 1;j < data.length;j+=2){
				data[j] += 100;
			}
		}
	} */

	/* list 5-9
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		Paint p = new Paint();
		RectF r = new RectF();
		for(int i = 1;i <= 10;i++){
			r.set(i * 22.5f, i * 22.5f, 100 + i * 22.5f, 100 + i * 22.5f);
			p.setColor(Color.argb(255, 0, i * 25, 0)); // ☆
			c.drawRect(r, p);
		}
	} */

	/* list 5-10
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		Paint p = new Paint();
		RectF r = new RectF();
		p.setColor(Color.GREEN);
		for(int i = 1;i <= 10;i++){
			r.set(i * 22.5f, i * 22.5f, 100 + i * 22.5f, 100 + i * 22.5f);
			p.setAlpha(i * 25); // ☆
			c.drawRect(r, p);
		}
	} */

	/* list 5-11
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		RectF r = new RectF(50, 50, 200, 200);
		Paint p = new Paint();
		p.setColor(Color.GREEN);
		p.setShadowLayer(10f, 50f, 50f, Color.DKGRAY);
		c.drawRect(r, p);
	}	*/

	/* list 5-12
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		RectF r = new RectF(50, 50, 200, 200);
		Paint p = new Paint();
		p.setColor(Color.RED);
		p.setShadowLayer(5f, 25f, 25f, Color.LTGRAY);
		p.setTextSize(64);
		p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
		c.drawText("Welcome!",10,50,p);
	} */

	/* list 5-13
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		Paint p = new Paint();
		p.setColor(Color.BLUE);
		Path path = new Path();
		path.addCircle(100, 100, 50, Path.Direction.CW);
		path.addCircle(300, 100, 50, Path.Direction.CW);
		path.addCircle(100, 300, 50, Path.Direction.CW);
		path.addCircle(300, 300, 50, Path.Direction.CW);
		path.addRect(100, 100, 300, 300, Path.Direction.CW);
		c.drawPath(path, p);
	} */

	/* list 5-14
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		Paint p = new Paint();
		p.setStyle(Paint.Style.STROKE);
		p.setStrokeWidth(50);
		p.setStrokeCap(Paint.Cap.SQUARE);
		p.setStrokeJoin(Paint.Join.BEVEL);
		p.setStrokeMiter(5f);
		p.setColor(Color.RED);
		Paint lp = new Paint();
		lp.setStyle(Paint.Style.STROKE);
		lp.setStrokeWidth(3);
		lp.setColor(Color.BLUE);
		Path path = new Path();
		path.moveTo(50, 50);
		path.lineTo(150, 150);
		path.lineTo(250, 50);
		path.lineTo(350, 150);
		c.drawPath(path, p);
		c.drawPath(path, lp);
	} */

	/* list 5-15
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		Paint p = new Paint();
		p.setStyle(Paint.Style.STROKE);
		p.setStrokeWidth(5f);
		p.setColor(Color.BLUE);
		Path path = new Path();
		path.moveTo(50, 50);
		path.quadTo(50, 150, 150, 150);
		path.cubicTo(250, 150, 150, 250, 300, 250);
		c.drawPath(path, p);
		c.drawPoint(50, 150, p);
		c.drawPoint(250, 150, p);
		c.drawPoint(150, 250, p);
	} */

	/* list 5-16 */
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		Paint p = new Paint();
		p.setColor(Color.BLUE);
		Path path = new Path();
		path.addCircle(200, 200, 150, Path.Direction.CW);
		path.addCircle(250, 200, 100, Path.Direction.CCW);
		path.addCircle(300, 200, 50, Path.Direction.CW);
		c.drawPath(path, p);
	}

}
