package jp.androidbook.myapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends Activity {
	static final String MENU_ITEM = "menu item";
	private PlaceholderFragment fragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		if (savedInstanceState == null) {
			fragment = new PlaceholderFragment();
			getFragmentManager().beginTransaction()
				.add(R.id.container, fragment)
				.commit();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		return super.onOptionsItemSelected(item);
	}

	/* list 7-2
	public static class PlaceholderFragment extends Fragment
		implements SensorEventListener {

		private SensorManager manager;
		float[] a_value;

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
										 Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container, false);
			return rootView;
		}

		@Override
		public void onStart() {
			super.onStart();
			manager = (SensorManager)getActivity().getSystemService(Activity.
				SENSOR_SERVICE);
			List<Sensor> a_sensors = manager.getSensorList(Sensor.
				TYPE_ACCELEROMETER);
			manager.registerListener(this, a_sensors.get(0), SensorManager.
				SENSOR_DELAY_FASTEST);

		}

		@Override
		public void onSensorChanged(SensorEvent sensorEvent) {
			a_value = sensorEvent.values.clone();
			if (a_value != null){
				TextView textView = (TextView)getActivity().findViewById(R.id.textView);
				textView.setText((int)a_value[0] + "\n" + (int)a_value[1] + "\n" +
					(int)a_value[2]);
			}
		}

		@Override
		public void onAccuracyChanged(Sensor sensor, int i) {
		}
	} */

	/* list 7-3 */
	public static class PlaceholderFragment extends Fragment
		implements SensorEventListener {

		private SensorManager manager;
		float[] a_value, m_value;

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
										 Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container, false);
			return rootView;
		}

		@Override
		public void onStart() {
			super.onStart();
			final Activity activity = getActivity();
			manager = (SensorManager)activity.getSystemService
				(Activity.SENSOR_SERVICE);
			List<Sensor> m_sensors = manager.getSensorList(Sensor.
				TYPE_MAGNETIC_FIELD);
			List<Sensor> a_sensors = manager.getSensorList
				(Sensor.TYPE_ACCELEROMETER);
			manager.registerListener(this, m_sensors.get(0), SensorManager.
				SENSOR_DELAY_FASTEST);
			manager.registerListener(this, a_sensors.get(0), SensorManager.
				SENSOR_DELAY_FASTEST);

		}

		@Override
		public void onSensorChanged(SensorEvent sensorEvent) {
			if (sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD){
				m_value = sensorEvent.values.clone();
			}
			if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
				a_value = sensorEvent.values.clone();
			}
			float[] rotate = new float[16];
			float[] inclinate = new float[16];
			float[] remaped = new float[16];
			float[] orientation = new float[3];

			if (a_value != null && m_value != null){
				SensorManager.getRotationMatrix(rotate, inclinate, a_value, m_value);
				SensorManager.remapCoordinateSystem(rotate, SensorManager.AXIS_X,
					SensorManager.AXIS_Z, remaped);
				SensorManager.getOrientation(remaped, orientation);
				float degree = (float)Math.toDegrees(orientation[0]);

				TextView textView = (TextView)getActivity().findViewById(R.id.textView);
				textView.setText("dgree:" + (int)degree);
			}
		}

		@Override
		public void onAccuracyChanged(Sensor sensor, int i) {

		}
	}

}

