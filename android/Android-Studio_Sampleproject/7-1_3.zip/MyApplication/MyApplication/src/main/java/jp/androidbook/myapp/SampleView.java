package jp.androidbook.myapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

public class SampleView extends View {

	public SampleView(Context context){
		super(context);
		initial(context);
	}

	public SampleView(Context context, AttributeSet attrs){
		super(context,attrs);
		initial(context);
	}

	public SampleView(Context context, AttributeSet attrs, int defstyle){
		super(context,attrs, defstyle);
		initial(context);
	}

	public void initial(Context context){
	}

	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);

	}

}