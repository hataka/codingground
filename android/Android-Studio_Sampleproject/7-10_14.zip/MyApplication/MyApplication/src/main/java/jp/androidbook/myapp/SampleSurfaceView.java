package jp.androidbook.myapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.provider.MediaStore;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.io.IOException;
import java.util.List;

public class SampleSurfaceView extends SurfaceView
	implements SurfaceHolder.Callback {

	private SurfaceHolder holder;
	private Camera camera;

	public SampleSurfaceView(Context context){
		super(context);
		initial();
	}

	public SampleSurfaceView(Context context, AttributeSet attrs){
		super(context, attrs);
		initial();
	}

	public SampleSurfaceView(Context context, AttributeSet attrs, int defStyle){
		super(context, attrs, defStyle);
		initial();
	}

	private void initial(){
		holder = this.getHolder();
		if (holder != null) {
			holder.addCallback(this);
		}
	}

	@Override
	public void surfaceCreated(SurfaceHolder surfaceHolder) {
		camera = Camera.open();
		try {
			if (camera != null) {
				camera.setPreviewDisplay(holder);
			}
		} catch (IOException e) {
			e.printStackTrace();
			camera.release();
			camera = null;
		}
	}

	@Override
	public void surfaceChanged(SurfaceHolder surfaceHolder, int fp, int w, int h) {
		camera.stopPreview();
		Camera.Parameters params = camera.getParameters();
		List<Camera.Size> previewSizes = camera.getParameters().
			getSupportedPreviewSizes();
		Camera.Size size = previewSizes.get(0);
		params.setPreviewSize(size.width, size.height);
		camera.setParameters(params);
		camera.startPreview();
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
		camera.stopPreview();
		camera.release();
		camera = null;
	}

	@Override
	public boolean onTouchEvent(MotionEvent event){
		if (event.getAction() == MotionEvent.ACTION_DOWN){
			camera.takePicture(null, null, new Camera.PictureCallback(){

				@Override
				public void onPictureTaken(byte[] bytes, Camera camera) {
					Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0,
						bytes.length, null);
					MediaStore.Images.Media.insertImage(
						getContext().getContentResolver(), bitmap,
						"myappication", "my application picture.");

				}
			});
		}
		return true;
	}
}