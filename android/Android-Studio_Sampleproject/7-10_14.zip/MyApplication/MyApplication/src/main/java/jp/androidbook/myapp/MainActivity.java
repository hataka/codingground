package jp.androidbook.myapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Vibrator;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends Activity {
	static final String MENU_ITEM = "menu item";
	private PlaceholderFragment fragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		if (savedInstanceState == null) {
			fragment = new PlaceholderFragment();
			getFragmentManager().beginTransaction()
				.add(R.id.container, fragment)
				.commit();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		menu.add(MENU_ITEM);
		menu.add("get location"); // ☆
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if ("get location".equals(item.getTitle())){
			fragment.checkGPS();
		}
		return super.onOptionsItemSelected(item);
	}

	public static class PlaceholderFragment extends Fragment
		implements LocationListener {
		private LocationManager manager;

		public PlaceholderFragment() {}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
										 Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container, false);
			return rootView;
		}

		@Override
		public void onStart() {
			super.onStart();
			manager = (LocationManager)getActivity().
				getSystemService(LOCATION_SERVICE);
		}

		public void checkGPS(){
			if (manager != null){
				manager.requestLocationUpdates(LocationManager.
					GPS_PROVIDER, 0, 0, this);
			}
		}

		@Override
		public void onLocationChanged(Location location) {
			double lat = location.getLatitude();
			double lng = location.getLongitude();
			lat = ((int)(lat * 1000)) / 1000d;
			lng = ((int)(lng * 1000)) / 1000d;
			TextView textView = (TextView)getActivity().findViewById(R.id.textView);
			textView.setText("LAT: " + lat + "\nLNG: " + lng);
			Vibrator vibrator = (Vibrator)getActivity().getSystemService(VIBRATOR_SERVICE);
			vibrator.vibrate(3);
			manager.removeUpdates(this);
		}

		@Override
		public void onStatusChanged(String s, int i, Bundle bundle) {}

		@Override
		public void onProviderEnabled(String s) {}

		@Override
		public void onProviderDisabled(String s) {}
	}

}


