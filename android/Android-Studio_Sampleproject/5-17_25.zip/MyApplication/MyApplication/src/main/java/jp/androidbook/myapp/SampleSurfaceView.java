package jp.androidbook.myapp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class SampleSurfaceView extends SurfaceView
	implements SurfaceHolder.Callback {
	private float drawX, drawY;

	public SampleSurfaceView(Context context){
		super(context);
		initial();
	}

	public SampleSurfaceView(Context context, AttributeSet attrs){
		super(context, attrs);
		initial();
	}

	public SampleSurfaceView(Context context, AttributeSet attrs, int defStyle){
		super(context, attrs, defStyle);
		initial();
	}

	private void initial(){
		SurfaceHolder holder = this.getHolder();
		holder.addCallback(this);
		drawX = 50f;
		drawY = 50f;
	}

	@Override
	public void surfaceCreated(SurfaceHolder surfaceHolder) {
		onDraw(surfaceHolder);
	}

	@Override
	public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
	}

	public void onDraw(SurfaceHolder holder){
		Canvas c = holder.lockCanvas();
		c.drawColor(Color.WHITE);
		Paint p = new Paint();
		p.setColor(Color.RED);
		c.drawCircle(drawX, drawY, 50, p);
		holder.unlockCanvasAndPost(c);
	}

	@Override
	public boolean onTouchEvent(MotionEvent e){
		drawX = e.getX();
		drawY = e.getY();
		onDraw(this.getHolder());
		return super.onTouchEvent(e);
	}

}