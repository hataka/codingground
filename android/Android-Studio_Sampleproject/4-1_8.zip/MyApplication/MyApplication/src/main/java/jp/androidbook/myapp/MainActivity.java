package jp.androidbook.myapp;

import android.app.Activity;
import android.app.ActionBar;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.os.Build;
import android.widget.DatePicker;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends Activity {
	static final String MENU_ITEM = "menu item"; //☆

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		if (savedInstanceState == null) {
			getFragmentManager().beginTransaction()
				.add(R.id.container, new PlaceholderFragment())
				.commit();
		}
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		menu.add(MENU_ITEM); //☆
		return true;
	}

	/* list 4-1
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (MENU_ITEM.equals(item.getTitle())){
			Toast toast = Toast.makeText(this,"Hello, Toast!!",
				Toast.LENGTH_LONG);
			toast.show();
		}
		return super.onOptionsItemSelected(item);
	} */

	/* list 4-2
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (MENU_ITEM.equals(item.getTitle())){
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("Message");
			builder.setMessage("これがアラートダイアログの表示です。");
			builder.show();
		}
		return super.onOptionsItemSelected(item);
	} */

	/* list 4-3
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (MENU_ITEM.equals(item.getTitle())){
			final Activity activity = this;
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("Message");
			builder.setMessage("これがアラートダイアログの表示です。");
			builder.setPositiveButton("わかった", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {
					Toast toast = Toast.makeText(activity , "ダイアログを閉じました。",
						Toast.LENGTH_LONG);
					toast.show();
				}
			});
			builder.setNegativeButton("キャンセル",new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {
					Toast toast = Toast.makeText(activity , "キャンセルしました。",
						Toast.LENGTH_LONG);
					toast.show();
				}
			});
			builder.show();
		}
		return super.onOptionsItemSelected(item);
	} */

	/* list 4-4
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (MENU_ITEM.equals(item.getTitle())){
			final Activity activity = this;
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("選択してください");
			final String[] items = {"ONE", "TWO", "THREE"};
			builder.setItems((CharSequence[])items, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {
					Toast toast = Toast.makeText(activity, items[i] + "を選択しました。",
						Toast.LENGTH_LONG);
					toast.show();
				}
			});
			builder.show();
		}
		return super.onOptionsItemSelected(item);
	} */

	/* list 4-5
	int selectedItem = 0; // フィールドを追加
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (MENU_ITEM.equals(item.getTitle())){
			final Activity activity = this;
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("選択してください。");
			final String[] items = {"ONE", "TWO", "THREE"};
			builder.setSingleChoiceItems((CharSequence[])items, 0, new DialogInterface.OnClickListener() { //☆
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {
					selectedItem = i;
					Toast toast = Toast.makeText(activity, items[i] + "でいいですか？",
						Toast.LENGTH_SHORT);
					toast.show();
				}
			});
			builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {
					Toast toast = Toast.makeText(activity, items[selectedItem] + "を選択しました。",
						Toast.LENGTH_LONG);
					toast.show();
				}
			});
			builder.show();
		}
		return super.onOptionsItemSelected(item);
	} */

	/* list 4-6
	boolean[] selectedItems = {false, false, false}; // フィールドを追加

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (MENU_ITEM.equals(item.getTitle())) {
			final Activity activity = this;
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("選択してください。");
			final String[] items = {"ONE", "TWO", "THREE"};
			builder.setMultiChoiceItems((CharSequence[]) items, selectedItems,
				new DialogInterface.OnMultiChoiceClickListener() {
					@Override
					public void onClick(DialogInterface dialogInterface, int i,
											  boolean checked) {
						selectedItems[i] = checked;
					}
				});
			builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int item) {
					String result = "";
					for(int i = 0;i < selectedItems.length;i++){
						if (selectedItems[i]){
							result += "".equals(result) ? "" : ", ";
							result += items[i];
						}
					}
					Toast toast = Toast.makeText(activity, result + " を選択しました。",
						Toast.LENGTH_LONG);
					toast.show();
				}
			});
			builder.show();
		}
		return super.onOptionsItemSelected(item);
	} */

	/* list 4-7
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (MENU_ITEM.equals(item.getTitle())) {
			final Timer timer = new Timer();
			final ProgressDialog dlog = new ProgressDialog(this);
			dlog.setTitle("経過表示");
			dlog.setMax(100);
			dlog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			dlog.setOnCancelListener(new DialogInterface.OnCancelListener() {
				@Override
				public void onCancel(DialogInterface dialogInterface) {
					timer.cancel();
				}
			});
			dlog.show();

			TimerTask task = new TimerTask() {
				@Override
				public void run() {
					dlog.incrementProgressBy(10);
					if (dlog.getProgress() >= dlog.getMax()){
						dlog.dismiss();
						timer.cancel();
					}
				}
			};
			timer.schedule(task,1000,1000);
		}
		return super.onOptionsItemSelected(item);
	} */

	/* list 4-8 */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (MENU_ITEM.equals(item.getTitle())) {
			final MainActivity activity = this;
			DatePickerDialog dlog = new DatePickerDialog(this,
				new DatePickerDialog.OnDateSetListener() {
					@Override
					public void onDateSet(DatePicker datePicker, int y, int m, int d) {
						Toast toast = Toast.makeText(activity, y + "年" + (m + 1) +
							"月" + d + "日",Toast.LENGTH_LONG);
						toast.show();
					}
				}, 2001, 0, 1);
			dlog.show();
		}
		return super.onOptionsItemSelected(item);
	}



	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
										 Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container, false);
			return rootView;
		}
	}

}
