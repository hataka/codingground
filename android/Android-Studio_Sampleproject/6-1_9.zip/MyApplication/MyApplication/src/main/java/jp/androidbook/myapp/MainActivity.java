package jp.androidbook.myapp;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
	static final String MENU_ITEM = "menu item";
	private PlaceholderFragment fragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		if (savedInstanceState == null) {
			fragment = new PlaceholderFragment();
			getFragmentManager().beginTransaction()
				.add(R.id.container, fragment)
				.commit();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		menu.add(MENU_ITEM);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (MENU_ITEM.equals(item.getTitle())){

		}
		return super.onOptionsItemSelected(item);
	}

	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
										 Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container, false);
			return rootView;
		}

		/* list 6-4
		@Override
		public void onStart() {
			super.onStart();
			final Activity activity = getActivity();
			Button button = (Button) activity.findViewById(R.id.main_button);
			button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					Intent intent = new Intent(activity,SecondActivity.class);
					activity.startActivity(intent);
				}
			});
		} */

		/* list 6-5
		@Override
		public void onStart() {
			super.onStart();
			final Activity activity = getActivity();
			Button button = (Button) activity.findViewById(R.id.main_button);
			button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					EditText edit1 = (EditText)activity.findViewById(R.id.main_editText);
					String msg = edit1.getText().toString();
					Intent intent = new Intent(activity,SecondActivity.class);
					intent.putExtra("msg", msg);
					intent.putExtra("title", "from MainActivity");
					activity.startActivity(intent);
				}
			});
		} */

		/* list 6-7 */
		@Override
		public void onStart() {
			super.onStart();
			final Activity activity = getActivity();
			Button button = (Button) activity.findViewById(R.id.main_button);
			button.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					EditText edit1 = (EditText)activity.findViewById(R.id.main_editText);
					String msg = edit1.getText().toString();
					Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
					intent.putExtra(Intent.EXTRA_EMAIL, new String[]{ msg });
					intent.putExtra(Intent.EXTRA_SUBJECT, "メール送信");
					intent.putExtra(Intent.EXTRA_TEXT, "メッセージ：");
					activity.startActivity(intent);
				}
			});
		}

	}

}
