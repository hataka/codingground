package jp.androidbook.myapp;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second);

		if (savedInstanceState == null) {
			PlaceholderFragment fragment = new PlaceholderFragment();
			getFragmentManager().beginTransaction()
				.add(R.id.sec_container, fragment)
				.commit();
		}
	}


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.second, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
										 Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_second, container, false);
			return rootView;
		}

		/* list 6-6
		@Override
		public void onStart() {
			super.onStart();
			Activity activity = getActivity();
			Intent intent = activity.getIntent();
			String msg = intent.getStringExtra("msg");
			String title = intent.getStringExtra("title");
			EditText edit1 = (EditText)activity.findViewById(R.id.sec_editText);
			edit1.setText(msg);
			TextView text1 = (TextView)activity.findViewById(R.id.sec_textView);
			text1.setText(title);
		} */

		/* list 6-8 */
		@Override
		public void onStart() {
			super.onStart();
			Activity activity = getActivity();
			Intent intent = activity.getIntent();
			if (intent.getAction().equals(Intent.ACTION_SENDTO)) {
				String[] msgs = intent.getStringArrayExtra(Intent.EXTRA_EMAIL);
				EditText edit1 = (EditText) activity.findViewById(R.id.sec_editText);
				edit1.setText("送信先：" + msgs[0]);
				String title = intent.getStringExtra("送信情報");
				TextView text1 = (TextView) activity.findViewById(R.id.sec_textView);
				text1.setText(title);
			}
		}

	}
}
