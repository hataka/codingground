package jp.androidbook.myapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;

public class SampleView extends View {

	public SampleView(Context context){
		super(context);
	}

	public SampleView(Context context, AttributeSet attrs){
		super(context,attrs);
	}

	public SampleView(Context context, AttributeSet attrs, int defstyle){
		super(context,attrs, defstyle);
	}

	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.RED);
	}

}
