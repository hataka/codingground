package jp.androidbook.myapp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class SampleSurfaceView extends SurfaceView
	implements SurfaceHolder.Callback {
	private float drawX, drawY;
	private float targetX, targetY;

	public SampleSurfaceView(Context context){
		super(context);
		initial();
	}

	public SampleSurfaceView(Context context, AttributeSet attrs){
		super(context, attrs);
		initial();
	}

	public SampleSurfaceView(Context context, AttributeSet attrs, int defStyle){
		super(context, attrs, defStyle);
		initial();
	}

	private void initial(){
		SurfaceHolder holder = this.getHolder();
		holder.addCallback(this);
		drawX = 50f;
		drawY = 50f;
		targetX = drawX;
		targetY = drawY;
	}

	private void startExecutor(){
		ScheduledExecutorService service =
			Executors.newSingleThreadScheduledExecutor();
		service.scheduleAtFixedRate(new Runnable() {
			@Override
			public void run() {
				Log.d("CHECK", "run-start: " + drawX + "," + drawY);
				drawX += (targetX - drawX) / 25;
				drawY += (targetY - drawY) / 25;
				onDraw(getHolder());
				Log.d("CHECK", "run-end: " + drawX + "," + drawY);
			}
		}, 50, 50, TimeUnit.MILLISECONDS);
	}
	@Override
	public void surfaceCreated(SurfaceHolder surfaceHolder) {
		onDraw(surfaceHolder);
		startExecutor();
	}

	@Override
	public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
	}

	@Override
	public boolean onTouchEvent(MotionEvent e){
		Log.d("CHECK","onTouch-start:" + drawX + "," + drawY);
		targetX = e.getX();
		targetY = e.getY();
		return super.onTouchEvent(e);
	}

	public void onDraw(SurfaceHolder holder){
		Canvas c = holder.lockCanvas();
		c.drawColor(Color.WHITE);
		Paint p = new Paint();
		p.setColor(Color.RED);
		c.drawCircle(drawX, drawY, 50, p);
		holder.unlockCanvasAndPost(c);
	}
}