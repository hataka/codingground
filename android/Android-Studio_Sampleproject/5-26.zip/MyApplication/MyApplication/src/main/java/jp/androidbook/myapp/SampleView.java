package jp.androidbook.myapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

public class SampleView extends View {
	private Bitmap image = null;

	public SampleView(Context context){
		super(context);
		initial(context);
	}

	public SampleView(Context context, AttributeSet attrs){
		super(context,attrs);
		initial(context);
	}

	public SampleView(Context context, AttributeSet attrs, int defstyle){
		super(context,attrs, defstyle);
		initial(context);
	}

	public void initial(Context context){
		Resources res = context.getResources();
		image = BitmapFactory.decodeResource(res, R.drawable.image);
	}

	/* list 5-17
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		Paint p = new Paint();
		if (image != null){
			c.drawBitmap(image, 0, 0, p);
		}
	} */

	/* list 5-18
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		if (image != null){
			Paint p = new Paint();
			int w = image.getWidth();
			int h = image.getHeight();
			Rect r1 = new Rect();
			RectF r2 = new RectF();
			for(int i = 0;i < (w / 50);i++){
				for(int j = 0;j < (h / 50);j++){
					r1.set(i * 50, j * 50, (i + 1) * 50, (j + 1) * 50);
					r2.set(i * 50 + i * 10, j * 50 + j * 10,
						(i + 1) * 50 + i * 10, (j + 1) * 50 + j * 10);
					c.drawBitmap(image,r1, r2, p);
				}
			}

		}
	} */

	/* list 5-19
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		if (image != null){
			Path path = new Path();
			path.addCircle(200, 250, 100, Path.Direction.CW);
			path.addCircle(100, 150, 50, Path.Direction.CW);
			path.addCircle(300, 150, 50, Path.Direction.CW);
			c.clipPath(path);
			Paint p = new Paint();
			c.drawBitmap(image,0, 0, p);
		}
	} */

	/* list 5-20 */
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas c){
		super.onDraw(c);
		c.drawColor(Color.WHITE);
		if (image != null){
			Path path = new Path();
			path.addCircle(200, 250, 100, Path.Direction.CW);
			path.addCircle(100, 150, 50, Path.Direction.CW);
			path.addCircle(300, 150, 50, Path.Direction.CW);
			c.save();
			c.clipPath(path);
			Paint p = new Paint();
			c.drawBitmap(image,0, 0, p);
			c.restore();
			p.setColor(Color.RED);
			p.setTextSize(36f);
			c.drawText("Clipping image is here!", 25,  225, p);
		}
	}


}