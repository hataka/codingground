package jp.androidbook.myapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

public class MainActivity extends Activity {
	static final String MENU_ITEM = "menu item";
	private PlaceholderFragment fragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		if (savedInstanceState == null) {
			fragment = new PlaceholderFragment();
			getFragmentManager().beginTransaction()
				.add(R.id.container, fragment)
				.commit();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		menu.add("Put Memo");
		menu.add("Get Memo");
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if ("Put Memo".equals(item.getTitle())) {
			EditText edit1 = (EditText)this.findViewById(R.id.main_editText);
			String memo = edit1.getText().toString();
			try {
				if (saveData(memo) != -1){
					Toast toast = Toast.makeText(this, "put memo!",
						Toast.LENGTH_SHORT);
					toast.show();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if ("Get Memo".equals(item.getTitle())) {
			EditText edit1 = (EditText)this.findViewById(R.id.main_editText);
			String memo = edit1.getText().toString();
			try {
				String res = loadData(memo);
				AlertDialog.Builder dlog = new AlertDialog.Builder(this);
				dlog.setTitle(memo);
				dlog.setMessage(res);
				dlog.create().show();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return super.onOptionsItemSelected(item);
	}

	// データの保存
	private long saveData(String data) throws IOException {
		String time = Calendar.getInstance().getTime().toString();
		MyDatabaseHelper helper = new MyDatabaseHelper(this);
		SQLiteDatabase db = helper.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(MyDatabaseHelper.MEMO, data);
		values.put(MyDatabaseHelper.DATETIME, time);
		long result = -1;
		if (db != null){
			result = db.insert(MyDatabaseHelper.TABLE_NAME, null, values);
		}
		return result;
	}

	// データの検索
	private String loadData(String find) throws IOException{
		MyDatabaseHelper helper = new MyDatabaseHelper(this);
		SQLiteDatabase db = helper.getReadableDatabase();
		String query = "select * from " + MyDatabaseHelper.TABLE_NAME +
			" where " + MyDatabaseHelper.MEMO + " like '%" + find + "%';";
		String result = "";
		if (db != null){
			Cursor c = db.rawQuery(query, null);
			if (c.moveToFirst()){
				result = c.getString(1) + "\n" + c.getString(2);
			}
		}
		return result;
	}

	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
										 Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container, false);
			return rootView;
		}
	}

}

class MyDatabaseHelper extends SQLiteOpenHelper {
	static final String ID = "id";
	static final String DATABASE_NAME = "mydatabase.db";
	static final int DATABASE_VERSION = 1;
	static final String TABLE_NAME = "mydata";
	static final String MEMO = "memo";
	static final String DATETIME = "datetime";

	MyDatabaseHelper(Context context){
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		String query = "create table " + TABLE_NAME + "(" +
			ID + " INTEGER PRIMARY KEY," +
			MEMO + " TEXT," +
			DATETIME + " TEXT);";
		db.execSQL(query);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("drop table if exists " + TABLE_NAME);
		onCreate(db);
	}
}
